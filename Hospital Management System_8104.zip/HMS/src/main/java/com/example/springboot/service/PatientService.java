package com.example.springboot.service;

import java.util.List;
import com.example.springboot.entity.Patients;

public interface PatientService {
	List<Patients> getAllPatients();
	Patients savePatient(Patients patient);
	Patients getPatientById(Long id);
	Patients updatePatient(Patients patient);
	void deletePatientById(Long id);

}
